from setuptools import setup

setup(
    name = 'vsearch',
    version = '1.1',
    py_modules = ['vsearch'],
)
